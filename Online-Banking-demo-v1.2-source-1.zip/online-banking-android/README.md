# Online Banking — projet Android WebView

Application Android qui embarque le prototype web dans une WebView. Le nom affiché est **Online Banking**.

## Ouvrir et générer l'APK
1. Installe Android Studio et le SDK Android (API 35 ou une version compatible).
2. Ouvre le dossier `online-banking-android` dans Android Studio.
3. Attends la synchronisation Gradle et accepte l'installation des composants SDK demandés.
4. Pour tester : bouton **Run** sur un émulateur ou un téléphone Android connecté.
5. Pour créer un APK de test : **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. L'APK de débogage est généralement généré dans `app/build/outputs/apk/debug/app-debug.apk`.

## Version 1.2 — démonstration finalisée
- Version Android mise à jour en 1.2 (versionCode 3).
- Parcours de démonstration vérifié : profil local, création d’une carte fictive, verrouillage/déverrouillage visuel, demande de recharge fictive MTN MoMo/Airtel Money, historique et réinitialisation.
- Les montants restent toujours à 0 FCFA et aucune transaction n’est envoyée.
- Aucun numéro de carte bancaire, CVV, code OTP ou donnée d’identité réelle n’est généré ni demandé.

## Améliorations de la version 1.1
- Design mobile retravaillé : panneaux plus lisibles, boutons adaptés au tactile et barre de navigation fixe en bas de l'écran.
- Icône de lancement Online Banking et couleurs harmonisées avec la marque.
- WebView améliorée : gestion du bouton Retour, restauration d'état, ouverture des liens web externes dans le navigateur et réduction de l'accès réseau/local inutile.
- Version Android portée à 1.1.

## Fonctionnalités actuelles
- Site d'accueil, tarifs, FAQ, contact, confidentialité et liste d'attente.
- Tableau de bord de démonstration avec profil local, carte fictive, verrouillage visuel, demandes de recharge fictives et historique local.
- Stockage local via le navigateur intégré.

## Générer l'APK
Dans Android Studio, ouvre ce dossier, laisse Gradle se synchroniser, puis utilise **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Le fichier APK de test sera normalement disponible dans `app/build/outputs/apk/debug/app-debug.apk`.

## Limites importantes
- Ce projet n'inclut pas de véritable émission de carte, de compte bancaire, de connexion sécurisée, de serveur, de recharge MTN MoMo/Airtel Money ou de paiement réel.
- Les actions et soldes sont uniquement des démonstrations. Ne collectez pas de vrais mots de passe, données de carte, codes OTP ou pièces d'identité.
- Pour un service réel, intégrer un partenaire autorisé via un backend sécurisé et faire valider les obligations réglementaires avant de lancer les transactions.

## Identifiant technique
`com.onlinebanking.app`


## Fonction ajoutée — création de carte (démo)
Le tableau de bord permet de créer une carte de démonstration avec un nom, un usage et un plafond simulé. La référence affichée est fictive : aucune PAN, aucun CVV, aucune expiration, aucune émission bancaire et aucun paiement réel. Pour émettre de vraies cartes, il faudra intégrer un fournisseur/émetteur autorisé via son API, avec les vérifications réglementaires et de sécurité nécessaires.


## Construire l’APK de démonstration
**Cette archive contient le projet source, pas un APK compilé.** Pour générer le fichier installable :
1. Sur un ordinateur, installe Android Studio et le SDK Android 35.
2. Ouvre le dossier `online-banking-android` dans Android Studio.
3. Attends la synchronisation Gradle et accepte les téléchargements de composants nécessaires.
4. Choisis **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Récupère `app-debug.apk` dans `app/build/outputs/apk/debug/`.

Si Android Studio signale l’absence du Gradle Wrapper, crée-le depuis un terminal avec Gradle installé (`gradle wrapper`) puis relance la synchronisation.
