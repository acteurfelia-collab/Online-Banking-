// Prototype de démonstration uniquement. Aucune API financière, aucun paiement réel.
const CLE = "macarte_demo_v2";
const MAX_HISTORIQUE = 30;
let etat = { carteCreee: false, carteVerrouillee: false, solde: 0, profil: "", historique: [], carteNom: "", carteType: "En ligne", carteLimite: 50000, carteReference: "" };

function charger() {
  try {
    const lu = JSON.parse(localStorage.getItem(CLE) || "null");
    if (!lu || typeof lu !== "object") return;
    etat.carteCreee = Boolean(lu.carteCreee);
    etat.carteVerrouillee = Boolean(lu.carteVerrouillee);
    // Le solde de production n'existe pas dans cette démo : il reste toujours à zéro.
    etat.solde = 0;
    etat.profil = typeof lu.profil === "string" ? lu.profil.slice(0, 40) : "";
    etat.carteNom = typeof lu.carteNom === "string" ? lu.carteNom.slice(0, 24) : "";
    etat.carteType = typeof lu.carteType === "string" ? lu.carteType.slice(0, 24) : "En ligne";
    etat.carteLimite = Number.isFinite(Number(lu.carteLimite)) ? Number(lu.carteLimite) : 50000;
    etat.carteReference = typeof lu.carteReference === "string" ? lu.carteReference.slice(0, 20) : "";
    etat.historique = Array.isArray(lu.historique) ? lu.historique.slice(0, MAX_HISTORIQUE) : [];
  } catch (e) { /* stockage local indisponible */ }
}
function sauvegarder() {
  try { localStorage.setItem(CLE, JSON.stringify({ carteCreee: etat.carteCreee, carteVerrouillee: etat.carteVerrouillee, profil: etat.profil, carteNom: etat.carteNom, carteType: etat.carteType, carteLimite: etat.carteLimite, carteReference: etat.carteReference, historique: etat.historique })); } catch (e) {}
}
function messageDans(id, texte, erreur) {
  const zone = document.getElementById(id);
  if (!zone) return;
  zone.textContent = texte;
  zone.classList.toggle("erreur", Boolean(erreur));
}
function afficherMessage(texte, erreur) { messageDans("message", texte, erreur); }
function formaterMontant(n) { return Number(n || 0).toLocaleString("fr-FR"); }
function ajouterHistorique(titre, detail) {
  etat.historique.unshift({ titre, detail, date: new Date().toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" }) });
  etat.historique = etat.historique.slice(0, MAX_HISTORIQUE);
}
function afficherHistorique() {
  const liste = document.getElementById("historique");
  if (!liste) return;
  liste.replaceChildren();
  if (!etat.historique.length) {
    const li = document.createElement("li"); li.className = "vide";
    li.textContent = "Aucune action pour le moment. Les actions suivantes resteront des démonstrations locales.";
    liste.appendChild(li); return;
  }
  etat.historique.forEach(ligne => {
    const li = document.createElement("li");
    const gauche = document.createElement("span"); gauche.textContent = ligne.titre;
    const petit = document.createElement("small"); petit.textContent = (ligne.date || "") + " — " + (ligne.detail || ""); gauche.appendChild(petit);
    const droite = document.createElement("span"); droite.className = "montant"; droite.textContent = "Démo";
    li.append(gauche, droite); liste.appendChild(li);
  });
}
function rafraichir() {
  const solde = document.getElementById("solde"); if (solde) solde.textContent = formaterMontant(0);
  const carte = document.getElementById("carte");
  const statut = document.getElementById("carte-statut");
  if (carte && statut) {
    carte.classList.toggle("inactive", !etat.carteCreee || etat.carteVerrouillee);
    statut.textContent = !etat.carteCreee ? "AUCUNE CARTE CRÉÉE" : (etat.carteVerrouillee ? "CARTE DÉMO VERROUILLÉE" : (etat.carteNom || "CARTE DÉMO").toUpperCase());
    const numero = document.getElementById("carte-numero"); if (numero) numero.textContent = etat.carteCreee ? etat.carteReference : "AUCUNE CARTE";
    const type = document.getElementById("carte-type-affiche"); if (type) type.textContent = etat.carteCreee ? etat.carteType.toUpperCase() : "DÉMO";
    const nomCarte = document.getElementById("carte-nom"); if (nomCarte && nomCarte.value !== etat.carteNom) nomCarte.value = etat.carteNom;
    const typeCarte = document.getElementById("carte-type"); if (typeCarte) typeCarte.value = etat.carteType;
    const limiteCarte = document.getElementById("carte-limite"); if (limiteCarte) limiteCarte.value = etat.carteLimite;
  }
  const verrou = document.getElementById("btn-verrouiller");
  if (verrou) { verrou.disabled = !etat.carteCreee; verrou.textContent = etat.carteVerrouillee ? "Déverrouiller la carte (démo)" : "Verrouiller la carte (démo)"; }
  const profil = document.getElementById("profil-prenom"); if (profil && profil.value !== etat.profil) profil.value = etat.profil;
  afficherHistorique();
}
function creerCarte(e) {
  if (e) e.preventDefault();
  const nomInput = document.getElementById("carte-nom");
  const typeInput = document.getElementById("carte-type");
  const limiteInput = document.getElementById("carte-limite");
  const nom = (nomInput && nomInput.value || "").trim().slice(0, 24);
  const limite = Number.parseInt(limiteInput && limiteInput.value, 10);
  if (!nom) { messageDans("message-carte", "Donne un nom à ta carte de démonstration.", true); return; }
  if (!Number.isInteger(limite) || limite < 1000 || limite > 5000000 || limite % 1000 !== 0) {
    messageDans("message-carte", "Choisis un plafond simulé entre 1 000 et 5 000 000 FCFA, par pas de 1 000.", true); return;
  }
  etat.carteCreee = true;
  etat.carteVerrouillee = false;
  etat.carteNom = nom;
  etat.carteType = typeInput ? typeInput.value : "En ligne";
  etat.carteLimite = limite;
  etat.carteReference = "DEMO-" + Math.random().toString(36).slice(2, 6).toUpperCase() + "-" + Math.random().toString(36).slice(2, 6).toUpperCase();
  ajouterHistorique("Carte virtuelle de démonstration créée", nom + " · " + etat.carteType + " · plafond simulé " + formaterMontant(limite) + " FCFA · " + etat.carteReference);
  sauvegarder(); rafraichir();
  messageDans("message-carte", "Carte de démonstration créée ! Référence " + etat.carteReference + ". Elle n'a ni numéro bancaire, ni CVV, ni date d'expiration et ne permet aucun paiement réel.");
  afficherMessage("Carte virtuelle de démonstration créée. Aucun émetteur bancaire n'a été contacté et aucun paiement n'est possible.");
}
function demanderRecharge() {
  if (!etat.carteCreee) { afficherMessage("Affiche d'abord la carte fictive. Aucune vraie carte ne sera créée.", true); return; }
  const input = document.getElementById("montant");
  const montant = Number.parseInt(input && input.value, 10);
  if (!Number.isInteger(montant) || montant < 500 || montant > 500000 || montant % 500 !== 0) {
    afficherMessage("Choisis un montant de 500 à 500 000 FCFA, par pas de 500.", true); return;
  }
  const moyen = document.querySelector('input[name="moyen"]:checked');
  const fournisseur = moyen ? moyen.value : "Mobile Money";
  const reference = "DEMO-" + Math.random().toString(36).slice(2, 8).toUpperCase();
  ajouterHistorique("Demande de recharge fictive", reference + " · " + formaterMontant(montant) + " FCFA · " + fournisseur + " · non envoyée");
  sauvegarder(); rafraichir();
  afficherMessage("Demande " + reference + " créée uniquement dans cette démo. Aucun paiement n'a été lancé, aucun opérateur contacté et le solde reste à 0 FCFA.");
}
function basculerVerrouillage() {
  if (!etat.carteCreee) return;
  etat.carteVerrouillee = !etat.carteVerrouillee;
  ajouterHistorique(etat.carteVerrouillee ? "Carte fictive verrouillée" : "Carte fictive déverrouillée", "État visuel local uniquement ; aucune carte réelle affectée");
  sauvegarder(); rafraichir(); afficherMessage("État de démonstration mis à jour. Cela ne verrouille ni ne déverrouille aucune carte réelle.");
}
function reinitialiser() {
  etat = { carteCreee: false, carteVerrouillee: false, solde: 0, profil: "", historique: [], carteNom: "", carteType: "En ligne", carteLimite: 50000, carteReference: "" };
  try { localStorage.removeItem(CLE); } catch (e) {}
  rafraichir(); afficherMessage("Données locales de démonstration réinitialisées. Aucun compte réel n'a été modifié.");
}
function initContact() {
  const form = document.getElementById("form-contact"); if (!form) return;
  form.addEventListener("submit", e => { e.preventDefault(); form.reset(); afficherMessage("Démo : le formulaire n'envoie ni n'enregistre votre message."); });
}
function initListe() {
  const form = document.getElementById("form-liste"); if (!form) return;
  form.addEventListener("submit", function(e) {
    e.preventDefault();
    const bouton = document.getElementById("btn-liste");
    const email = document.getElementById("courriel").value.trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { afficherMessage("Entrez une adresse email valide.", true); return; }
    if (!document.getElementById("consentement").checked) { afficherMessage("Cochez la case de consentement pour continuer.", true); return; }
    if (document.getElementById("site").value) return;
    const adresse = window.MARQUE && window.MARQUE.formulaireListe;
    if (!adresse) { afficherMessage("Liste d'attente non connectée : aucune donnée n'a été envoyée ni enregistrée. Configurez formulaireListe dans js/config.js.", true); return; }
    bouton.disabled = true;
    fetch(adresse, { method: "POST", headers: { Accept: "application/json" }, body: new FormData(form) })
      .then(r => { if (r.ok) { form.reset(); afficherMessage("Inscription envoyée au service configuré."); } else { afficherMessage("Impossible d'enregistrer l'inscription. Réessayez.", true); } })
      .catch(() => afficherMessage("Connexion impossible. Réessayez plus tard.", true))
      .finally(() => { bouton.disabled = false; });
  });
}
function initTableau() {
  if (!document.getElementById("btn-creer")) return;
  charger(); rafraichir();
  const formCarte = document.getElementById("form-creer-carte");
  if (formCarte) formCarte.addEventListener("submit", creerCarte);
  document.getElementById("btn-recharger").addEventListener("click", demanderRecharge);
  document.getElementById("btn-reinit").addEventListener("click", reinitialiser);
  const verrou = document.getElementById("btn-verrouiller"); if (verrou) verrou.addEventListener("click", basculerVerrouillage);
  const formProfil = document.getElementById("form-profil");
  if (formProfil) formProfil.addEventListener("submit", e => {
    e.preventDefault(); const champ = document.getElementById("profil-prenom");
    const nom = (champ.value || "").trim().slice(0, 40);
    if (!nom) { messageDans("message-profil", "Saisis un nom d'affichage fictif.", true); return; }
    etat.profil = nom; ajouterHistorique("Profil local modifié", "Nom d'affichage enregistré uniquement dans ce navigateur"); sauvegarder(); rafraichir();
    messageDans("message-profil", "Profil de démonstration enregistré localement. N'utilise pas de données personnelles réelles.");
  });
  const effacer = document.getElementById("btn-effacer-profil");
  if (effacer) effacer.addEventListener("click", () => { etat.profil = ""; ajouterHistorique("Profil local effacé", "Aucune donnée envoyée à un serveur"); sauvegarder(); rafraichir(); messageDans("message-profil", "Profil effacé de cette démo."); });
  document.querySelectorAll(".rapides button").forEach(b => b.addEventListener("click", () => { document.getElementById("montant").value = b.dataset.montant; }));
}
document.addEventListener("DOMContentLoaded", () => { initContact(); initListe(); initTableau(); });
