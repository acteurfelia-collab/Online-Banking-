// Réglages de la marque : modifie uniquement ce fichier pour changer le nom, les couleurs et les liens.
window.MARQUE = {
  // Nom affiché partout sur le site
  nom: "Online Banking",

  // Couleurs (format #rrggbb)
  couleurPrincipale: "#0f3b2e",
  couleurAccent: "#f2b705",

  // Ton adresse email de contact, affichée sur la page Confidentialité
  // Exemple : "contact@tonsite.com"
  emailContact: "",

  // Adresse d'envoi de la liste d'attente (voir README, étape « Relier la liste d'attente »)
  // Exemple avec Formspree : "https://formspree.io/f/xxxxxxxx"
  // Tant que cette valeur est vide, le formulaire n'envoie rien et le dit clairement.
  formulaireListe: ""
};

document.addEventListener("DOMContentLoaded", function () {
  var m = window.MARQUE;
  var racine = document.documentElement.style;
  if (m.couleurPrincipale) racine.setProperty("--foret", m.couleurPrincipale);
  if (m.couleurAccent) racine.setProperty("--soleil", m.couleurAccent);
  if (m.nom) {
    document.title = document.title.replace(/Online Banking/g, m.nom);
    document.querySelectorAll("[data-marque]").forEach(function (el) {
      el.textContent = m.nom;
    });
  }
  document.querySelectorAll("[data-email-contact]").forEach(function (el) {
    el.textContent = m.emailContact || "(adresse à renseigner dans js/config.js)";
  });
});


// Navigation compacte pour téléphone : les liens restent accessibles sur toutes les pages.
document.addEventListener("DOMContentLoaded", function () {
  if (document.querySelector(".mobile-nav")) return;
  var current = (location.pathname.split("/").pop() || "index.html").toLowerCase();
  var items = [
    { href: "index.html", label: "Accueil", icon: "⌂", files: ["", "index.html"] },
    { href: "dashboard.html", label: "Espace client", icon: "▣", files: ["dashboard.html"] },
    { href: "tarifs.html", label: "Tarifs", icon: "◇", files: ["tarifs.html"] },
    { href: "faq.html", label: "Aide", icon: "?", files: ["faq.html", "contact.html", "confidentialite.html", "liste-attente.html"] }
  ];
  var nav = document.createElement("nav");
  nav.className = "mobile-nav";
  nav.setAttribute("aria-label", "Navigation mobile");
  items.forEach(function (item) {
    var a = document.createElement("a");
    a.href = item.href;
    a.className = item.files.indexOf(current) >= 0 ? "actif" : "";
    var icon = document.createElement("span");
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = item.icon;
    var label = document.createElement("span");
    label.textContent = item.label;
    a.append(icon, label);
    nav.appendChild(a);
  });
  document.body.appendChild(nav);
});
