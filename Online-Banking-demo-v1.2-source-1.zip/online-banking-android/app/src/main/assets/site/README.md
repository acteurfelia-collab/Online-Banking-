# Prototype de cartes virtuelles — démonstration et liste d'attente

**Démonstration — aucune transaction réelle.** Aucune clé API, aucun compte mobile money réel, aucune pièce d'identité collectée. Seule la page de liste d'attente peut enregistrer un email, avec l'accord de la personne, et seulement après configuration (voir plus bas).

## Voir le site
1. Ouvrir le dossier dans Visual Studio Code.
2. Installer l'extension **Live Server**.
3. Clic droit sur `index.html` → **Open with Live Server**.

## Changer le nom et les couleurs
Ouvre `js/config.js` et modifie `nom`, `couleurPrincipale`, `couleurAccent`. Le changement s'applique à toutes les pages.

## Relier la liste d'attente (gratuit)
Tant que rien n'est configuré, le formulaire n'envoie rien et l'affiche clairement.
1. Crée un compte gratuit sur un service de formulaires (par exemple Formspree) et crée un formulaire.
2. Copie l'adresse d'envoi qu'il te donne.
3. Colle-la dans `formulaireListe` dans `js/config.js`.
4. Renseigne aussi `emailContact` (affiché sur la page Confidentialité).
5. Teste avec ta propre adresse email et vérifie que tu la reçois.

Avant de partager le site : relis `confidentialite.html` et fais-la relire par un juriste.

## Publier gratuitement
Des services comme GitHub Pages, Netlify ou Cloudflare Pages hébergent un site statique gratuitement. Vérifie leurs conditions actuelles.

## Fichiers
- `index.html` : accueil et aperçu de carte fictive
- `dashboard.html` : espace client de démonstration, profil local, carte fictive verrouillable, solde toujours nul, demandes de recharge non envoyées
- `tarifs.html`, `faq.html`, `contact.html` (contact de démonstration, n'envoie rien)
- `liste-attente.html`, `confidentialite.html`
- `css/style.css`, `js/app.js`, `js/config.js`
- `FEUILLE-DE-ROUTE.md` : étapes pour passer à un vrai service


## Fonctions ajoutées dans cette version
- Profil de démonstration enregistré uniquement dans le navigateur (nom d'affichage fictif, pas de vrai compte).
- Affichage d'une carte fictive et bascule de verrouillage visuel.
- Demande de recharge de démonstration avec référence locale ; aucun appel MTN MoMo/Airtel Money et aucun solde crédité.
- Historique local des actions de démo.

**Important :** `localStorage` n'est ni une authentification sécurisée ni une base de données serveur. Ne demande pas de vrai mot de passe, numéro de téléphone, pièce d'identité ou données bancaires dans ce prototype. Toute intégration réelle doit être réalisée côté serveur avec un partenaire agréé, une authentification sécurisée et des contrôles de conformité.


## Fonctions ajoutées dans cette version
- Profil de démonstration enregistré uniquement dans le navigateur (nom d'affichage fictif, pas de vrai compte).
- Affichage d'une carte fictive et bascule de verrouillage visuel.
- Demande de recharge de démonstration avec référence locale ; aucun appel MTN MoMo/Airtel Money et aucun solde crédité.
- Historique local des actions de démo.

**Important :** `localStorage` n'est ni une authentification sécurisée ni une base de données serveur. Ne demande pas de vrai mot de passe, numéro de téléphone, pièce d'identité ou données bancaires dans ce prototype. Toute intégration réelle doit être réalisée côté serveur avec un partenaire agréé, une authentification sécurisée et des contrôles de conformité.
