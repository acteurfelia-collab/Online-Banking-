# Feuille de route : de la démo à un vrai service de cartes virtuelles

Ce document décrit les grandes étapes pour passer d'un prototype à un vrai service au Congo-Brazzaville et en zone CEMAC. Il ne remplace pas l'avis d'un juriste local ni celui des autorités. **Vérifie chaque point avec les sources officielles avant de t'engager.**

## 1. Comprendre ce que tu es (et ce que tu n'es pas)

Émettre une carte et conserver l'argent des clients sont des activités financières encadrées. Pour démarrer sans budget énorme, le modèle le plus réaliste est souvent celui-ci :

- **Toi** : la marque, l'application, la relation client, le marketing.
- **Un partenaire agréé** (banque, établissement de monnaie électronique ou fintech déjà autorisée) : il émet les cartes, détient les fonds et fait les vérifications d'identité.

À clarifier tôt : qui émet la carte, qui détient l'argent, qui est responsable en cas de problème.

## 2. Règles à vérifier avant toute collecte d'argent

À confirmer auprès des autorités de la zone CEMAC et du Congo (régulation bancaire et monétaire, services de paiement) et d'un juriste local :

- Quelle autorisation faut-il pour émettre des cartes ou de la monnaie électronique, et peut-on passer par un partenaire déjà autorisé ?
- Quelles vérifications d'identité des clients sont obligatoires (lutte contre le blanchiment et le financement du terrorisme) ?
- Quelles règles s'appliquent à la protection des données personnelles ?
- Quels plafonds de solde et de transaction s'appliquent aux cartes prépayées ?

## 3. Partenaires à contacter

- **Établissements financiers** : banques et fintechs agréées qui proposent des cartes prépayées en marque blanche ou en partenariat.
- **Opérateurs mobile money (MTN MoMo, Airtel Money)** : demande leurs conditions pour un partenaire ou un marchand, leurs outils pour développeurs et les frais. L'accès réel demande en général une entreprise enregistrée et un contrat.
- **Juriste ou conseil local** : pour les statuts, la conformité et les contrats.

## 4. Valider la demande avant de dépenser

Tout ceci coûte peu ou rien :

- Publier la liste d'attente (pages `liste-attente.html` et `confidentialite.html`).
- Parler à 15 à 20 personnes de ta cible (jeunes actifs, freelances, commerçants en ligne) : à quoi leur servirait une carte virtuelle, que paient-ils aujourd'hui, qu'est-ce qui les freine ?
- Tester les prix avec la page Tarifs et noter les réactions.
- Compter : combien d'inscrits, combien disent utiliser MTN MoMo ou Airtel Money.

## 5. Postes de budget à prévoir (à chiffrer avec tes devis)

- Enregistrement de l'entreprise
- Conseil juridique et conformité
- Frais du partenaire émetteur (mise en place, par carte, par transaction)
- Hébergement, sécurité, outils de support client
- Marketing et acquisition des premiers clients

## 6. Les 30 prochains jours

1. Choisir le nom de marque et le renseigner dans `js/config.js`.
2. Relier la liste d'attente (voir README) et renseigner ton email de contact.
3. Publier le site gratuitement et partager le lien auprès de ta cible.
4. Rédiger la liste de 5 partenaires potentiels (2 financiers, MTN, Airtel, 1 juriste) et leur écrire.
5. Faire les 15 à 20 conversations avec des clients potentiels.
6. Noter dans un tableau : ce que chaque partenaire exige (agrément, capital, délais, frais).
7. Décider : continuer, ajuster ou arrêter, selon les réponses obtenues.

## Règle d'or

Tant qu'un partenaire agréé n'a pas dit oui par écrit, **aucun vrai argent ne passe par ton site** et rien ne doit laisser croire qu'une vraie carte existe.


## État du prototype après mise à jour
Le tableau de bord contient maintenant un profil local de démonstration, un état visuel de carte (créée/verrouillée), un solde qui reste toujours à 0 FCFA et des demandes de recharge non envoyées. Une référence `DEMO-...` n'est qu'un identifiant de test local. Aucun paiement ne doit être présenté comme réussi.

## Pour une version réelle (à ne pas activer depuis le navigateur seul)
1. Créer un backend HTTPS avec une base de données et une authentification adaptée.
2. Faire émettre les cartes et traiter les soldes uniquement par le partenaire contractuel autorisé.
3. Créer côté serveur une demande de paiement via l'API officielle du partenaire Mobile Money, puis confirmer son statut avec une notification serveur vérifiée. Ne jamais créditer un solde à partir d'une simple réponse du navigateur.
4. Ajouter journalisation, limites, détection de fraude, gestion des remboursements et support client.
5. Effectuer une revue juridique, sécurité et protection des données avant toute mise en production.


## État du prototype après mise à jour
Le tableau de bord contient maintenant un profil local de démonstration, un état visuel de carte (créée/verrouillée), un solde qui reste toujours à 0 FCFA et des demandes de recharge non envoyées. Une référence `DEMO-...` n'est qu'un identifiant de test local. Aucun paiement ne doit être présenté comme réussi.

## Pour une version réelle (à ne pas activer depuis le navigateur seul)
1. Créer un backend HTTPS avec une base de données et une authentification adaptée.
2. Faire émettre les cartes et traiter les soldes uniquement par le partenaire contractuel autorisé.
3. Créer côté serveur une demande de paiement via l'API officielle du partenaire Mobile Money, puis confirmer son statut avec une notification serveur vérifiée. Ne jamais créditer un solde à partir d'une simple réponse du navigateur.
4. Ajouter journalisation, limites, détection de fraude, gestion des remboursements et support client.
5. Effectuer une revue juridique, sécurité et protection des données avant toute mise en production.
